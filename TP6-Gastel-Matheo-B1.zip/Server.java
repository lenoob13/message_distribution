package notification;
import java.util.HashMap;
import java.util.Map;
import notification.Subscriber;
/** 
 * The server class manages the subscribers and sends alerts to them.
 */
public class Server {
    /** 
     * The subscribers map, where the key will be the subscriber's name and the value is the subscriber object.
     */
    private Map<String,Subscriber> subscribers ;
    /** 
     * Constructor for the Server class.
     * Initializes the subscribers map.
     */
    public Server() {
        subscribers = new HashMap<>();
    }

    /**
     * Adds a new subscriber to the server with the given name, communication mode, and address.
     * Validates that the name, mode, and address are not null or empty, and that the mode is either "sms" or "mail".
     * If a subscriber with the same name already exists, an error message is printed.
     * 
     * @param clientName the name of the subscriber to add.
    * @param mode the communication mode (either "sms" or "mail").
    * @param adr the address of the subscriber.
    */
    public void adherer(String clientName,String mode,String adr){
        if (clientName == null || clientName.equals("")){
            System.out.println("Le nom ne peut pas etre vide");
        }else if(!mode.toLowerCase().equals("sms") && !mode.toLowerCase().equals("mail") && !mode.toLowerCase().equals("xmess")&& !mode.toLowerCase().equals("chat")){
            System.out.println("Le mode de communication doit etre sms, mail, chat ou xmess");
        }else if (adr == null || adr.equals("")){
            System.out.println("L'adresse ne peut pas etre vide");
        }if (subscribers.containsKey(clientName)) {
            System.out.println("Un abonné avec ce nom existe déjà.");
        } else {
            String modeM=mode.toLowerCase();
            CommunicationStrategy strategy=CommunicationAccess.getCom(modeM);
            if (strategy==null){
                strategy = CommunicationFactory.create(modeM);
                CommunicationAccess.setCom(modeM,strategy);
            }
            try {
                Subscriber subscriber = new Subscriber(new String(clientName), modeM, new String(adr));
                subscribers.put(subscriber.getNom(), subscriber);
            } catch (IllegalArgumentException e) {
                System.out.println("Abonné non créé : " + e.getMessage());
            }
        }
    }

    /**
     * Remove a subscriber from the server by their name.
     * If the subscriber is not found, print an error message.
     * @param clientName the name of the subscriber to remove.
     */
    public void retirer(String clientName){
        if (clientName == null || clientName.equals("")){
            System.out.println("Le nom ne peut pas etre vide");
        }else{
            if (subscribers.containsKey(clientName)){
                subscribers.remove(clientName);
            }else{
                System.out.println("Aucun abonné avec ce nom.");
            }
        }
    }

    /**
     * Sends a message to all subscribers.
     * For each subscriber, it gets the subscriber's communication strategy
     * and sends the message to the subscriber using the strategy.
     * @param message the message to send to all subscribers.
     */
    public void alerter(String message){
        if (message == null || message.equals("")){
            System.out.println("Le message ne peut pas etre vide.");
        }else{
            for (Subscriber sub : subscribers.values()){
                // get the strategy
                CommunicationStrategy strategy=CommunicationAccess.getCom(sub.getMode());
                // send of the message
                if (sub.getAdresse()=="default"){
                    System.out.println("le message pour "+sub.getNom()+" n'as pas été envoyé");
                }else{
                strategy.envoyer(sub.getNom(),sub.getAdresse(),message);
                }
            }
        }
    }

    /**
     * Returns a list of all current subscribers in the form of an array of strings.
     * Each string represents a subscriber's details.
     * 
     * @return an array of strings representing the subscribers.
     */
    public String[] getListeInscrits(){
        String[] list = new String[subscribers.size()];
        int i = 0;
        for (Subscriber sub : subscribers.values()){
            list[i] = sub.toString();
            i++;
        }
        return list;
    }
}