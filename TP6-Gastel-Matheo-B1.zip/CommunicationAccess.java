package notification;
import java.util.HashMap;
import java.util.Map;

/**
 * The CommunicationAccess class stores different CommunicationStrategy objects in a HashMap.
 * The key is the mode of communication, and the value is the corresponding strategy.
 */
class CommunicationAccess {
    /**
     * The medias map stores communication strategies.
     * The key represents the mode of communication (e.g., "email", "sms").
     * The value is an instance of CommunicationStrategy implementing the corresponding behavior.
     */
    private static Map<String, CommunicationStrategy> medias = new HashMap<>();

    /**
     * Private constructor to prevent instantiation.
     * This class follows the Singleton pattern for centralized access to communication strategies.
     */
    private CommunicationAccess() {}

    /**
     * Registers a communication strategy for a given mode.
     *
     * @param mode   The communication mode.
     * @param comObj The CommunicationStrategy object to associate with the mode.
     */
    public static void setCom(String mode, CommunicationStrategy comObj) {
        medias.put(mode, comObj);
    }

    /**
     * Retrieves the communication strategy associated with the given mode.
     *
     * @param mode The communication mode to retrieve the strategy for.
     * @return The corresponding CommunicationStrategy, or null if no strategy is found.
     */
    public static CommunicationStrategy getCom(String mode) {
        return medias.get(mode);
    }
}
