package notification;
import utilitaire.ComNet;
/**
 * ComNetAdaptator is a class that implements the CommunicationStrategy interface and sends messages using the ComNet class.
 */
class ComNetAdaptator implements CommunicationStrategy{
    /**
     * The ComNet object used to send messages.
     */
    private ComNet comNet;

    /**
     * Constructor for the ComNetAdaptator class.
     */
    public ComNetAdaptator() {
        this.comNet = new ComNet();
    }

    /**
     * Send a message to a subscriber using the ComNet class.
     * @param clientName the name of the subscriber.
     * @param adresse the address of the subscriber.
     * @param message the message to send to the subscriber.
     */
    @Override
    public void envoyer(String clientName,String adresse,String message){
        comNet.send(adresse, message);
        System.out.println("[ComNet ("+adresse+") -> "+clientName+"] "+message);
    }
}