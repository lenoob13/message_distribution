package notification;
/**
 * This class represents a subscriber in the notification system.
 * It has a name, communication mode, address, and communication strategy.
 */
class Subscriber{
    /** 
     * The name of the subscriber.
     */
    private final String nom;
    /** 
     * The communication mode used by the subscriber.
     */
    private final String mode;
    /** 
     * The address of the subscriber. 
     */
    private final String adresse;
    /**
     * Create a new subscriber.
     * @param nom the name of the subscriber.
     * @param mode the communication mode used by the subscriber.
     * @param adresse the address of the subscriber.
     */
    public Subscriber(String nom,String mode,String adresse){
        if (nom == null || nom.equals("")){
            System.out.println("Le nom ne peut pas etre vide");
            this.nom="default";
        }else{
            this.nom=new String(nom);
        }
        if (!mode.toLowerCase().equals("sms") && !mode.toLowerCase().equals("mail") && !mode.toLowerCase().equals("xmess") && !mode.toLowerCase().equals("chat")){
            System.out.println("Le mode de communication doit etre sms, mail, chat ou xmess, pas : "+mode);
            this.mode="default";
        }else{
            this.mode=new String(mode.toLowerCase());
        }
        CommunicationStrategy strat=CommunicationAccess.getCom(this.mode);

        if (!strat.isCorrect(adresse)){
            System.out.println("L'adresse n'est pas valide");
            throw new IllegalArgumentException("adresse invalide : " + adresse);
        }else if(adresse == null || adresse.equals("")){
            System.out.println("L'adresse ne peut pas etre vide");
            this.adresse="default";
        }else{
            this.adresse=new String(adresse);
        }
    }
    
    /**
     * Return the name of the subscriber.
     * @return the name of the subscriber.
     */
    public String getNom(){
        return this.nom;
    }

    /**
     * Return the communication mode used by the subscriber.
     * @return the communication mode used by the subscriber.
     */
    public String getMode(){
        return this.mode;
    }

    /**
     * Return the address of the subscriber.
     * @return the address of the subscriber.
     */
    public String getAdresse(){
        return this.adresse;
    }

    /**
     * Return a string representation of the subscriber.
     * @return a string representation of the subscriber (nom adresse (mode))
     */
    @Override
    public String toString() {
        return nom + " " + adresse + " (" + mode + ")";
    }
}