package application;
import notification.Server;
/**
* Cette classe ne contient qu’un main démonstrateur du bon fonctionnement
* du service d’alerte.
*/
public class TestServer{
    /**
    * Exécution d'exemples d’usage du service.
    */
    public static void main(String[] args) {
        Server serveur = new Server();
        // Inscription
        serveur.adherer("Alice", "SMS", "0633343536");
        serveur.adherer("Bob", "MAIL","bob@orange.fr");
        serveur.adherer("Théo", "Xmess","@théolololo");
        serveur.adherer("Ferdinand", "CHAT","IDK");
        //erreur car 08
        serveur.adherer("Lucie","SMS","0808080808");
        //erreur car pas que chiffre
        serveur.adherer("Liam","SMS","070808aaaa");
        //erreur car trop court
        serveur.adherer("Élian","SMS","060808089");
        //alerte
        serveur.alerter("Bonjour, voici une alerte importante!");
        // Désinscription de Bob
        serveur.retirer("Bob");
        serveur.retirer("Théo");
        serveur.retirer("Ferdinand");
        // Ajout d'un nouveau client
        serveur.adherer("Charlie", "MAIL", "charlie@orange.fr");
        // Envoi d'une autre alerte
        serveur.alerter("Deuxième alerte!");
        // Affichage des inscrits
        String[] inscrits = serveur.getListeInscrits();
        System.out.println("Liste des inscrits : Nom Adresse (mode)");
        for(String ins : inscrits){
            System.out.println(ins);
        }
    }
}