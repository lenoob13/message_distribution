package notification;
/**
 * This class implements the Xmess communication mode.
 * It sends a message to a subscriber using the Xmess communication mode.
 */
class XmessCommunication  implements CommunicationStrategy{
    /**
     * Send a message to a subscriber using SMS.
     * @param clientName the name of the subscriber.
     * @param adresse the address of the subscriber.
     * @param message the message to send.
     */
    @Override
    public void envoyer(String clientName,String adresse,String message){
        System.out.println("[Xmess ("+adresse+") -> "+clientName+"] <("+message+")");
    }
}