package notification;
/**
 * The MailCommunication class implements the CommunicationStrategy interface and provides a method to send a message to a subscriber using the mail communication mode.
 * The message is printed to the console with the given client name and address.
 */
class MailCommunication  implements CommunicationStrategy{
    /**
     * Sends a message to a subscriber using the mail communication mode.
     * The message is printed to the console with the given client name and address.
     * @param clientName the name of the subscriber to send the message to.
     * @param adresse the address of the subscriber.
     * @param message the message to send to the subscriber.
     */
    @Override
    public void envoyer(String clientName,String adresse,String message){
        System.out.println("[MAIL ("+adresse+") -> "+clientName+"] "+message);//[MAIL (bob@orange.fr) -> Bob] Bonjour, voici une alerte importante!
    }
}