package notification;
/** 
 * The CommunicationFactory class creates communication strategies based on the given mode.
 */
class CommunicationFactory {
    private CommunicationFactory(){}
    /**
     * Return a communication strategy based on the given mode.
     * @param mode the mode of the communication strategy to create (either "sms" or "mail").
     * @return the requested communication strategy, or null if the mode is unknown.
     */
    public static CommunicationStrategy create (String mode){
        String modeM=mode.toLowerCase();
        switch (modeM){
            case "sms":
                return new SmsCommunication();
            case "mail":
                return new MailCommunication();
            case "xmess":
                return new XmessCommunication();
            case "chat":
                return new ComNetAdaptator();
            default:
                System.out.println("Mode de communication inconnu : "+modeM);
                return null;
        }
    }
}