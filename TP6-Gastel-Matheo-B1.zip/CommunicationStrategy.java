package notification;
/**
 * Interface representing a communication strategy for a subscriber.
 */
interface CommunicationStrategy {
    /**
     * Abstract method to send a message to a subscriber.
     * @param clientName the name of the client
     * @param adresse the adresse of the client
     * @param message the message to send to the client
     */
    void envoyer (String clientName,String adresse,String message);
    /**
     * This Abstract 
     * @param adresse
     * @return True when the method isn't implemented
     */
    default boolean isCorrect(String adresse){
        return true ;
    }
}