package notification;
/**
 * The SmsCommunication class implements the CommunicationStrategy interface and sends a message to a subscriber using SMS.
 */
class SmsCommunication  implements CommunicationStrategy{
    /**
     * Send a message to a subscriber using SMS.
     * @param clientName the name of the subscriber.
     * @param adresse the address of the subscriber.
     * @param message the message to send.
     */
    @Override
    public void envoyer(String clientName,String adresse,String message){
        System.out.println("[SMS ("+adresse+") -> "+clientName+"] "+message);
    }
    private boolean isNumeric(String str){
        for (char c : str.toCharArray()){
            if (!Character.isDigit(c)){
                return false;
            }
        }
        return true;
    }
    /**
     * @param adresse the adress of the subscriber
     * @return boolean that indicate if the adresse is valid and can be used
     */
    @Override
    public boolean isCorrect(String adresse){
        if (adresse.length()!= 10 || !isNumeric(adresse)){
            return false;
        }
        else{
            String deuxChiffre=new String();
            for (int i=0;i<2;i++){
                deuxChiffre=deuxChiffre+adresse.charAt(i);
            }
            if (!deuxChiffre.equals("07") && !deuxChiffre.equals("06")){
                return false;
            }
            return true;
        }
    }
}