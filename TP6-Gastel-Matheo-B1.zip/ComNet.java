package utilitaire;
/**
 * Class ComNet is a class for sending messages using the ComNet protocol.
 * It prints the message to the console with the prefix "*-ComNet ".
 */
public class ComNet {
    /**
     * Sends a message to the given login using the ComNet protocol.
     * Prints the message to the console with the prefix "*-ComNet ".
     * @param login the login to which to send the message.
     * @param message the message to send.
     */
    public void send(String login, String message){
        System.out.print("*-ComNet ");
    }
}